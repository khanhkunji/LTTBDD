package com.dqk.myapp.activity.user;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.dqk.myapp.R;
import com.dqk.myapp.activity.LoginActivity;
import com.dqk.myapp.adapter.BannerAdapter;
import com.dqk.myapp.adapter.CategoryAdapter;
import com.dqk.myapp.adapter.ProductAdapter;
import com.dqk.myapp.database.CategoryDAO;
import com.dqk.myapp.database.DatabaseHelper;
import com.dqk.myapp.database.ProductDAO;
import com.dqk.myapp.model.Category;
import com.dqk.myapp.model.Product;
import com.dqk.myapp.utils.CartManager;
import com.dqk.myapp.utils.SessionManager;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class UserMainActivity extends AppCompatActivity {

    private ProductDAO productDAO;
    private CategoryDAO categoryDAO;
    private SessionManager session;

    private ProductAdapter newProductAdapter, bestSellerAdapter;
    private RecyclerView rvNewProducts, rvBestSeller, rvCategories;
    private EditText etSearch;
    private LinearLayout layoutHotProduct;
    private ListView listSuggestions;
    private final List<String> allSuggestions = new ArrayList<>();

    // Banner
    private Handler bannerHandler;
    private Runnable bannerRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_main);

        session     = new SessionManager(this);
        productDAO  = new ProductDAO(DatabaseHelper.getInstance(this));
        categoryDAO = new CategoryDAO(DatabaseHelper.getInstance(this));

        initViews();
        setupSuggestions();
        setupSearch();
        setupLogout();
    }

    private void initViews() {
        rvCategories   = findViewById(R.id.rvCategories);
        rvNewProducts  = findViewById(R.id.rvNewProducts);
        rvBestSeller   = findViewById(R.id.rvBestSeller);
        etSearch       = findViewById(R.id.etSearch);
        layoutHotProduct = findViewById(R.id.layoutHotProduct);
        listSuggestions  = findViewById(R.id.listSuggestions);

        rvCategories.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvNewProducts.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvBestSeller.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
        // Cập nhật badge giỏ hàng
        CartManager.getInstance().init(this, session.getUserId());
        int cartCount = CartManager.getInstance().getTotalItems();
        TextView tvCartBadge = findViewById(R.id.tvCartBadge);
        if (tvCartBadge != null) {
            tvCartBadge.setText(String.valueOf(cartCount));
            tvCartBadge.setVisibility(cartCount > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void loadData() {
        // === Banner tự động chuyển ảnh SP bán chạy ===
        setupBanner();

        // === Card SP bán chạy nhất ===
        List<Product> hotList = productDAO.getBestSellerProducts(1);
        if (!hotList.isEmpty()) {
            Product hot = hotList.get(0);
            layoutHotProduct.setVisibility(View.VISIBLE);

            ImageView imgHot    = findViewById(R.id.imgHotProduct);
            TextView tvHotName  = findViewById(R.id.tvHotProductName);
            TextView tvHotPrice = findViewById(R.id.tvHotProductPrice);
            TextView tvHotSold  = findViewById(R.id.tvHotProductSold);

            tvHotName.setText(hot.getName());
            NumberFormat fmt = NumberFormat.getInstance(new Locale("vi", "VN"));
            tvHotPrice.setText(fmt.format(hot.getPrice()) + " đ");
            tvHotSold.setText("Đã bán: " + hot.getSoldCount() + " sản phẩm");

            String rawUrl = hot.getImageUrl();
            String firstUrl = (rawUrl != null && rawUrl.contains(","))
                    ? rawUrl.split(",")[0].trim() : rawUrl;
            Glide.with(this)
                    .load(firstUrl)
                    .placeholder(R.color.gray_placeholder)
                    .error(R.color.gray_placeholder)
                    .into(imgHot);

            findViewById(R.id.cardHotProduct).setOnClickListener(v ->
                    openProductDetail(hot));
        } else {
            layoutHotProduct.setVisibility(View.GONE);
        }

        // === Danh mục ===
        List<Category> categories = categoryDAO.getAll();
        CategoryAdapter categoryAdapter = new CategoryAdapter(this, categories);
        categoryAdapter.setOnItemClickListener(category -> {
            Intent intent = new Intent(this, ProductListActivity.class);
            intent.putExtra("category_id", category.getId());
            intent.putExtra("category_name", category.getName());
            startActivity(intent);
        });
        rvCategories.setAdapter(categoryAdapter);

        // === Sản phẩm mới ===
        List<Product> newProducts = productDAO.getNewestProducts(6);
        newProductAdapter = new ProductAdapter(this, newProducts);
        newProductAdapter.setOnItemClickListener(this::openProductDetail);
        rvNewProducts.setAdapter(newProductAdapter);

        // === Bán chạy nhất ===
        List<Product> bestSellers = productDAO.getBestSellerProducts(6);
        bestSellerAdapter = new ProductAdapter(this, bestSellers);
        bestSellerAdapter.setOnItemClickListener(this::openProductDetail);
        rvBestSeller.setAdapter(bestSellerAdapter);
    }

    private void setupBanner() {
        ViewPager2 viewPagerBanner = findViewById(R.id.viewPagerBanner);
        if (viewPagerBanner == null) return;

        // Hủy handler cũ nếu có
        if (bannerHandler != null && bannerRunnable != null) {
            bannerHandler.removeCallbacks(bannerRunnable);
        }

        // Lấy ảnh từ top 5 SP bán chạy
        List<String> bannerUrls = new ArrayList<>();
        for (Product p : productDAO.getBestSellerProducts(5)) {
            if (p.getImageUrl() != null && !p.getImageUrl().isEmpty()) {
                String url = p.getImageUrl().contains(",")
                        ? p.getImageUrl().split(",")[0].trim()
                        : p.getImageUrl();
                bannerUrls.add(url);
            }
        }
        // Fallback: SP mới nhất nếu chưa có bán chạy
        if (bannerUrls.isEmpty()) {
            for (Product p : productDAO.getNewestProducts(5)) {
                if (p.getImageUrl() != null && !p.getImageUrl().isEmpty()) {
                    String url = p.getImageUrl().contains(",")
                            ? p.getImageUrl().split(",")[0].trim()
                            : p.getImageUrl();
                    bannerUrls.add(url);
                }
            }
        }

        if (bannerUrls.isEmpty()) {
            viewPagerBanner.setVisibility(View.GONE);
            return;
        }

        viewPagerBanner.setVisibility(View.VISIBLE);
        viewPagerBanner.setAdapter(new BannerAdapter(this, bannerUrls));

        // Tự động chuyển slide mỗi 3 giây
        int total = bannerUrls.size();
        int[] current = {0};
        bannerHandler  = new Handler();
        bannerRunnable = new Runnable() {
            @Override
            public void run() {
                current[0] = (current[0] + 1) % total;
                viewPagerBanner.setCurrentItem(current[0], true);
                bannerHandler.postDelayed(this, 3000);
            }
        };
        bannerHandler.postDelayed(bannerRunnable, 3000);
    }

    private void setupSearch() {
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            String keyword = etSearch.getText().toString().trim();
            if (!keyword.isEmpty()) {
                listSuggestions.setVisibility(View.GONE);
                Intent intent = new Intent(this, SearchActivity.class);
                intent.putExtra("keyword", keyword);
                startActivity(intent);
                etSearch.setText("");
            }
            return true;
        });
    }

    private void setupSuggestions() {
        for (Product p : productDAO.getAllProducts()) {
            allSuggestions.add(p.getName());
        }

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = s.toString().trim();
                if (input.length() >= 1) {
                    List<String> filtered = new ArrayList<>();
                    for (String name : allSuggestions) {
                        if (name.toLowerCase().contains(input.toLowerCase())) {
                            filtered.add(name);
                            if (filtered.size() >= 5) break;
                        }
                    }
                    if (!filtered.isEmpty()) {
                        listSuggestions.setAdapter(new ArrayAdapter<>(
                                UserMainActivity.this,
                                android.R.layout.simple_list_item_1,
                                filtered));
                        listSuggestions.setVisibility(View.VISIBLE);
                        listSuggestions.setOnItemClickListener((parent, view, pos, id) -> {
                            String selected = filtered.get(pos);
                            etSearch.setText("");
                            listSuggestions.setVisibility(View.GONE);
                            Intent intent = new Intent(UserMainActivity.this, SearchActivity.class);
                            intent.putExtra("keyword", selected);
                            startActivity(intent);
                        });
                    } else {
                        listSuggestions.setVisibility(View.GONE);
                    }
                } else {
                    listSuggestions.setVisibility(View.GONE);
                }
            }
        });
    }

    private void setupLogout() {
        LinearLayout tvCart         = findViewById(R.id.tvCart);
        LinearLayout tvOrderHistory = findViewById(R.id.tvOrderHistory);
        LinearLayout tvLogout       = findViewById(R.id.tvLogout);

        tvCart.setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class)));
        tvOrderHistory.setOnClickListener(v ->
                startActivity(new Intent(this, OrderHistoryActivity.class)));
        tvLogout.setOnClickListener(v -> {
            session.logout();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void openProductDetail(Product product) {
        Intent intent = new Intent(this, ProductDetailActivity.class);
        intent.putExtra("product_id", product.getId());
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bannerHandler != null && bannerRunnable != null) {
            bannerHandler.removeCallbacks(bannerRunnable);
        }
    }
}
