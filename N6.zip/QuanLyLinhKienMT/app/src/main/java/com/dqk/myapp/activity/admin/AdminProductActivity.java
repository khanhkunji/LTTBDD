package com.dqk.myapp.activity.admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dqk.myapp.R;
import com.dqk.myapp.adapter.CategoryAdminAdapter;
import com.dqk.myapp.database.CategoryDAO;
import com.dqk.myapp.database.DatabaseHelper;
import com.dqk.myapp.model.Category;

import java.util.List;

public class AdminProductActivity extends AppCompatActivity {

    private CategoryDAO categoryDAO;
    private List<Category> categoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_product_category);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Quản lý Sản phẩm");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        categoryDAO  = new CategoryDAO(DatabaseHelper.getInstance(this));
        setupRecyclerView();


    }
    private void setupRecyclerView() {
        categoryList = categoryDAO.getAll();
        RecyclerView rvCategories = findViewById(R.id.rvCategories);
        TextView tvEmpty          = findViewById(R.id.tvEmpty);

        if (categoryList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            rvCategories.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvCategories.setVisibility(View.VISIBLE);

            // Dùng lại CategoryAdminAdapter nhưng override click
            CategoryAdminAdapter adapter =
                    new CategoryAdminAdapter(this, categoryList);
            rvCategories.setLayoutManager(new LinearLayoutManager(this));
            rvCategories.setAdapter(adapter);

            // Nhấn vào danh mục → mở ProductByCategoryActivity
            adapter.setOnItemClickListener(category -> {
                Intent intent = new Intent(this,
                        ProductByCategoryActivity.class);
                intent.putExtra(ProductByCategoryActivity.EXTRA_CATEGORY_ID,
                        category.getId());
                intent.putExtra(ProductByCategoryActivity.EXTRA_CATEGORY_NAME,
                        category.getName());
                startActivity(intent);
            });

            adapter.setShowActions(false); // thêm dòng này sau khi tạo adapter
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupRecyclerView(); // Reload số lượng SP khi quay lại
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}