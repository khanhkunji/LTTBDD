package com.dqk.myapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dqk.myapp.R;

import java.util.List;

public class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.ViewHolder> {

    private final Context context;
    private final List<String> imageUrls;

    public BannerAdapter(Context context, List<String> imageUrls) {
        this.context   = context;
        this.imageUrls = imageUrls;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context)
                .inflate(R.layout.item_banner, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Glide.with(context)
                .load(imageUrls.get(position))
                .placeholder(R.color.gray_placeholder)
                .error(R.color.gray_placeholder)
                .centerCrop()
                .into(h.ivBanner);
    }

    @Override
    public int getItemCount() { return imageUrls == null ? 0 : imageUrls.size(); }

    // Fix ViewPager2 cache bug
    @Override
    public int getItemViewType(int position) { return position; }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivBanner;
        ViewHolder(@NonNull View v) {
            super(v);
            ivBanner = v.findViewById(R.id.ivBanner);
        }
    }
}