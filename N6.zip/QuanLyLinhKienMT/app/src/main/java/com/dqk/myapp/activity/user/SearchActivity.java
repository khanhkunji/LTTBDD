package com.dqk.myapp.activity.user;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dqk.myapp.R;
import com.dqk.myapp.adapter.ProductAdapter;
import com.dqk.myapp.database.DatabaseHelper;
import com.dqk.myapp.database.ProductDAO;
import com.dqk.myapp.model.Product;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private ProductDAO productDAO;
    private ProductAdapter adapter;
    private EditText etSearch;
    private TextView tvEmpty, tvResultCount;
    private RecyclerView rvResults;
    private ListView listSuggestions;
    private final List<String> allSuggestions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Tìm kiếm");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Khởi tạo views
        productDAO      = new ProductDAO(DatabaseHelper.getInstance(this));
        etSearch        = findViewById(R.id.etSearch);
        tvEmpty         = findViewById(R.id.tvEmpty);
        tvResultCount   = findViewById(R.id.tvResultCount);
        rvResults       = findViewById(R.id.rvResults);
        listSuggestions = findViewById(R.id.listSuggestions);
        Button btnSearch = findViewById(R.id.btnSearch);

        rvResults.setLayoutManager(new GridLayoutManager(this, 2));

        // Load tên sản phẩm vào danh sách gợi ý
        for (Product p : productDAO.getAllProducts()) {
            allSuggestions.add(p.getName());
        }

        // Lắng nghe nhập text → hiện gợi ý
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = s.toString().trim();
                if (input.length() >= 1) {
                    // Lọc sản phẩm có tên chứa input
                    List<String> filtered = new ArrayList<>();
                    for (String name : allSuggestions) {
                        if (name.toLowerCase().contains(input.toLowerCase())) {
                            filtered.add(name);
                            if (filtered.size() >= 5) break; // tối đa 5 gợi ý
                        }
                    }

                    if (!filtered.isEmpty()) {
                        listSuggestions.setAdapter(new ArrayAdapter<>(
                                SearchActivity.this,
                                android.R.layout.simple_list_item_1,
                                filtered));
                        listSuggestions.setVisibility(View.VISIBLE);

                        // Nhấn vào gợi ý → search luôn
                        listSuggestions.setOnItemClickListener((parent, view, pos, id) -> {
                            String selected = filtered.get(pos);
                            etSearch.setText(selected);
                            // Đặt con trỏ về cuối
                            etSearch.setSelection(selected.length());
                            listSuggestions.setVisibility(View.GONE);
                            performSearch(selected);
                        });
                    } else {
                        listSuggestions.setVisibility(View.GONE);
                    }
                } else {
                    listSuggestions.setVisibility(View.GONE);
                }
            }
        });

        // Nhận keyword từ trang chủ nếu có
        String keyword = getIntent().getStringExtra("keyword");
        if (keyword != null && !keyword.isEmpty()) {
            etSearch.setText(keyword);
            listSuggestions.setVisibility(View.GONE);
            performSearch(keyword);
        }

        // Nút Tìm
        btnSearch.setOnClickListener(v -> {
            listSuggestions.setVisibility(View.GONE);
            performSearch(etSearch.getText().toString().trim());
        });

        // Nhấn Enter
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                listSuggestions.setVisibility(View.GONE);
                performSearch(etSearch.getText().toString().trim());
                return true;
            }
            return false;
        });
    }

    @SuppressLint("SetTextI18n")
    private void performSearch(String keyword) {
        if (keyword.isEmpty()) {
            tvEmpty.setText("Nhập từ khóa để tìm kiếm");
            tvEmpty.setVisibility(View.VISIBLE);
            rvResults.setVisibility(View.GONE);
            tvResultCount.setVisibility(View.GONE);
            return;
        }

        List<Product> results = productDAO.searchProducts(keyword);

        if (results.isEmpty()) {
            tvEmpty.setText("Không tìm thấy \"" + keyword + "\"");
            tvEmpty.setVisibility(View.VISIBLE);
            rvResults.setVisibility(View.GONE);
            tvResultCount.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvResults.setVisibility(View.VISIBLE);
            tvResultCount.setVisibility(View.VISIBLE);
            tvResultCount.setText("Tìm thấy " + results.size() + " sản phẩm");

            if (adapter == null) {
                adapter = new ProductAdapter(this, results);
                adapter.setOnItemClickListener(product -> {
                    Intent intent = new Intent(this, ProductDetailActivity.class);
                    intent.putExtra("product_id", product.getId());
                    startActivity(intent);
                });
                rvResults.setAdapter(adapter);
            } else {
                adapter.updateList(results);
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}