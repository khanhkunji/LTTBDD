package com.dqk.myapp.utils;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

import com.dqk.myapp.database.DatabaseHelper;
import com.dqk.myapp.database.OrderDAO;
import com.dqk.myapp.database.ProductDAO;
import com.dqk.myapp.model.Order;
import com.dqk.myapp.model.Product;

import android.content.Context;
import android.util.Log;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirebaseSyncManager {

    private static final String TAG = "FirebaseSync";
    private static final String DATABASE_URL =
            "https://quanlylinhkienmaytinh-default-rtdb.asia-southeast1.firebasedatabase.app";
    private static FirebaseSyncManager instance;

    private final DatabaseReference rootRef;
    private final OrderDAO orderDAO;
    private final ProductDAO productDAO;
    private boolean orderStatusListening;
    private boolean productListening;

    // Singleton
    public static FirebaseSyncManager getInstance(Context ctx) {
        if (instance == null) {
            instance = new FirebaseSyncManager(ctx);
        }
        return instance;
    }

    private FirebaseSyncManager(Context ctx) {
        rootRef    = FirebaseDatabase.getInstance(DATABASE_URL).getReference();
        orderDAO   = new OrderDAO(DatabaseHelper.getInstance(ctx));
        productDAO = new ProductDAO(DatabaseHelper.getInstance(ctx));
    }

    // =========================================================
    // SYNC ĐƠN HÀNG: SQLite → Firebase
    // =========================================================
    public void syncOrdersToFirebase() {
        List<Order> unsynced = orderDAO.getUnsyncedOrders();
        if (unsynced.isEmpty()) {
            Log.d(TAG, "Không có đơn hàng mới cần sync");
            return;
        }

        for (Order order : unsynced) {
            // Tạo Map để lưu lên Firebase
            Map<String, Object> orderMap = new HashMap<>();
            orderMap.put("id",          order.getId());
            orderMap.put("user_id",     order.getUserId());
            orderMap.put("total_price", order.getTotalPrice());
            orderMap.put("status",      order.getStatus());
            orderMap.put("order_date",  order.getOrderDate());

            // Lưu vào node "orders/{orderId}"
            rootRef.child("orders")
                    .child(String.valueOf(order.getId()))
                    .setValue(orderMap)
                    .addOnSuccessListener(aVoid -> {
                        // Đánh dấu đã sync trong SQLite
                        orderDAO.markAsSynced(order.getId());
                        Log.d(TAG, "Sync đơn #" + order.getId() + " thành công");
                    })
                    .addOnFailureListener(e ->
                            Log.e(TAG, "Sync đơn #" + order.getId() + " thất bại: " + e.getMessage())
                    );
        }
    }

    // =========================================================
    // SYNC TRẠNG THÁI ĐƠN HÀNG: Firebase → SQLite (real-time)
    // =========================================================
    public void listenOrderStatusChanges() {
        if (orderStatusListening) {
            return;
        }
        orderStatusListening = true;

        rootRef.child("orders")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            String status = child.child("status")
                                    .getValue(String.class);
                            String idStr  = child.getKey();
                            if (idStr != null && status != null) {
                                int orderId = Integer.parseInt(idStr);
                                // Cập nhật trạng thái vào SQLite local
                                orderDAO.updateStatus(orderId, status);
                                Log.d(TAG, "Nhận update đơn #"
                                        + orderId + " → " + status);
                            }
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {
                        orderStatusListening = false;
                        Log.e(TAG, "Listen lỗi: " + error.getMessage());
                    }
                });
    }

    // =========================================================
    // SYNC SẢN PHẨM: Firebase → SQLite
    // (Admin cập nhật giá/tồn kho từ Firebase Console)
    // =========================================================
    public void listenProductChanges() {
        if (productListening) {
            return;
        }
        productListening = true;

        rootRef.child("products")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            Integer id    = child.child("id").getValue(Integer.class);
                            Double  price = child.child("price").getValue(Double.class);
                            Integer stock = child.child("stock").getValue(Integer.class);

                            if (id != null && price != null && stock != null) {
                                productDAO.updatePriceAndStock(id, price, stock);
                                Log.d(TAG, "Cập nhật SP #" + id);
                            }
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {
                        productListening = false;
                        Log.e(TAG, "Lỗi: " + error.getMessage());
                    }
                });
    }

    public void updateOrderStatusInFirebase(int orderId, String status) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);

        rootRef.child("orders")
                .child(String.valueOf(orderId))
                .updateChildren(update)
                .addOnSuccessListener(aVoid ->
                        Log.d(TAG, "Đã cập nhật trạng thái đơn #" + orderId + " lên Firebase"))
                .addOnFailureListener(e ->
                        Log.e(TAG, "Cập nhật trạng thái đơn #" + orderId
                                + " lên Firebase thất bại: " + e.getMessage()));
    }

    // =========================================================
    // PUSH SẢN PHẨM: SQLite → Firebase (1 lần khi mở app)
    // =========================================================
    public void pushProductsToFirebase() {
        List<Product> products = productDAO.getAllProducts();
        if (products.isEmpty()) {
            Log.d(TAG, "Không có sản phẩm để push lên Firebase");
            return;
        }

        Map<String, Object> productsMap = new HashMap<>();
        for (Product p : products) {
            Map<String, Object> map = new HashMap<>();
            map.put("id",    p.getId());
            map.put("name",  p.getName());
            map.put("price", p.getPrice());
            map.put("stock", p.getStock());
            map.put("sold_count", p.getSoldCount());
            map.put("is_active", p.getIsActive());
            productsMap.put(String.valueOf(p.getId()), map);
        }

        rootRef.child("products")
                .setValue(productsMap)
                .addOnSuccessListener(aVoid ->
                        Log.d(TAG, "Đã push " + products.size()
                                + " sản phẩm lên Firebase tại " + DATABASE_URL))
                .addOnFailureListener(e ->
                        Log.e(TAG, "Push sản phẩm thất bại: " + e.getMessage()));
    }
}
