DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- Bảng: users
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    full_name TEXT,
    email TEXT UNIQUE,
    phone TEXT,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Bảng: categories
CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT
);

-- Bảng: products
CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    stock INTEGER DEFAULT 0,
    image_url TEXT,
    sold_count INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP, specification TEXT DEFAULT '',
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Bảng: orders
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    total_price REAL NOT NULL,
    status TEXT DEFAULT 'pending',
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Bảng: order_items
CREATE TABLE order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Bảng: reviews
CREATE TABLE reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    rating INTEGER NOT NULL,
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ============================================================
-- DỮ LIỆU MẪU
-- ============================================================

-- ---- USERS (5 bản ghi) ----
INSERT INTO users (id, username, password, full_name, email, phone, role, created_at) VALUES
    (1, 'KhanhAdmin2k2', 'khanh2k2', 'Nguyen Minh Khanh', 'khanhadmin@linhkienmt.com', '0901234567', 'admin', '2026-03-31 17:38:18'),
    (2, 'KhanhUser2k2', 'khanh2k2', 'Khanh User', 'khanhuser@gmail.com', '0912345678', 'user', '2026-03-31 17:38:18'),
    (3, 'nguyenvana', 'abc123', 'Nguyen Van A', 'vana@gmail.com', '0923456789', 'user', '2026-03-31 17:38:18'),
    (4, 'tranthib', 'abc123', 'Tran Thi B', 'thib@gmail.com', '0934567890', 'user', '2026-03-31 17:38:18'),
    (5, 'levanc', 'abc123', 'Le Van C', 'vanc@gmail.com', '0945678901', 'user', '2026-03-31 17:38:18');

-- ---- CATEGORIES (6 bản ghi) ----
INSERT INTO categories (id, name, description) VALUES
    (1, 'CPU', 'Bộ vi xử lý Intel và AMD các thế hệ mới nhất'),
    (2, 'RAM', 'Bộ nhớ trong DDR4 và DDR5 tốc độ cao'),
    (3, 'Ổ cứng', 'Ổ cứng SSD NVMe, SATA và HDD dung lượng lớn'),
    (4, 'VGA', 'Card màn hình NVIDIA GeForce và AMD Radeon'),
    (5, 'Mainboard', 'Bo mạch chủ Intel và AMD các dòng cao cấp'),
    (6, 'Nguồn máy', 'Bộ nguồn máy tính công suất 550W đến 1000W');

-- ---- PRODUCTS (25 bản ghi) ----
INSERT INTO products (id, category_id, name, description, price, stock, image_url, sold_count, is_active, created_at, specification) VALUES
    (1, 1, 'Intel Core i5-12400F', 'CPU Intel thế hệ 12, 6 nhân 12 luồng, xung nhịp 2.5GHz boost 4.4GHz, TDP 65W, không tích hợp GPU', 3500000.0, 20, 'https://cdn.phototourl.com/free/2026-04-10-655fe0e5-f02b-4fd7-9fa9-325a45cc0e5e.jpg, https://cdn.phototourl.com/free/2026-04-10-071335f9-5eb0-424c-a33a-d96aae2d3eef.jpg', 15, 1, '2026-03-31 17:38:18', '6 nhân 12 luồng, Socket LGA1700, TDP 65W'),
    (2, 1, 'Intel Core i7-12700K', 'CPU Intel thế hệ 12, 12 nhân 20 luồng, xung nhịp 3.6GHz boost 5.0GHz, TDP 125W, hiệu năng cao cấp', 7500000.0, 10, 'https://cdn.phototourl.com/free/2026-04-11-2131df0a-1d57-4a30-a932-ca66c03c510f.webp, https://cdn.phototourl.com/free/2026-04-11-752753bd-7de5-4bdd-b40b-be744103852c.jpg', 8, 1, '2026-03-31 17:38:18', '12 nhân 20 luồng, Socket LGA1700, TDP 125W'),
    (3, 1, 'AMD Ryzen 5 5600X', 'CPU AMD Zen 3, 6 nhân 12 luồng, xung nhịp 3.7GHz boost 4.6GHz, TDP 65W, hiệu năng xuất sắc tầm trung', 4200000.0, 15, 'https://cdn.phototourl.com/free/2026-04-11-6d77cd6c-6b62-47e7-a374-399edbe5796a.webp, https://cdn.phototourl.com/free/2026-04-11-add99a48-6661-4a98-8e90-bc9559f33ec1.jpg', 22, 1, '2026-03-31 17:38:18', '6 nhân 12 luồng, Socket AM4, TDP 65W'),
    (4, 1, 'AMD Ryzen 7 5800X', 'CPU AMD Zen 3, 8 nhân 16 luồng, xung nhịp 3.8GHz boost 4.7GHz, TDP 105W, lý tưởng cho đồ họa và gaming', 6200000.0, 12, 'https://cdn.phototourl.com/free/2026-04-11-171dd9ee-cf28-4838-a176-5530bd86384f.jpg, https://cdn.phototourl.com/free/2026-04-11-c955166b-d407-4062-ae39-ad56214c3cdc.jpg', 11, 1, '2026-03-31 17:38:18', '8 nhân 16 luồng, Socket AM4, TDP 105W'),
    (5, 1, 'Intel Core i9-12900K', 'CPU Intel thế hệ 12 cao cấp nhất, 16 nhân 24 luồng, xung nhịp 3.2GHz boost 5.2GHz, flagship 2022', 12500000.0, 5, 'https://cdn.phototourl.com/free/2026-04-11-b5b46e06-8231-4448-bd62-3aaee7bbbd41.jpg, https://cdn.phototourl.com/free/2026-04-11-907ce304-d6c3-474e-a05f-a88033971be5.jpg', 3, 1, '2026-03-31 17:38:18', ''),
    (6, 2, 'Kingston 8GB DDR4 3200MHz', 'RAM Kingston Fury Beast 8GB DDR4 bus 3200MHz, tản nhiệt nhôm, phù hợp PC văn phòng và gaming nhẹ', 650000.0, 50, 'https://cdn.phototourl.com/member/2026-04-11-e06ee78a-1bc9-43da-8dd9-c3be69ad88ee.webp', 40, 1, '2026-03-31 17:38:18', 'DDR4 3200MHz, 8GB, CL22'),
    (7, 2, 'Kingston 16GB DDR4 3200MHz', 'RAM Kingston Fury Beast 16GB DDR4 bus 3200MHz, tản nhiệt nhôm, hiệu năng ổn định cho đa nhiệm', 980000.0, 40, 'https://cdn.phototourl.com/member/2026-04-11-37a82348-25ed-494b-850a-5192b8363bd9.webp', 18, 1, '2026-03-31 17:38:18', 'DDR4 3200MHz, 16GB, CL22'),
    (8, 2, 'Corsair 16GB DDR4 3600MHz', 'RAM Corsair Vengeance RGB 16GB DDR4 bus 3600MHz, đèn RGB 10 vùng, tương thích XMP 2.0', 1350000.0, 25, 'https://cdn.phototourl.com/member/2026-04-11-1e70ca9e-5e3e-4be7-b9ec-95dd5402fd5a.webp', 14, 1, '2026-03-31 17:38:18', ''),
    (9, 2, 'G.Skill 32GB DDR4 3600MHz', 'RAM G.Skill Trident Z RGB 32GB DDR4 bus 3600MHz, thiết kế sang trọng, phù hợp workstation', 2400000.0, 15, 'https://cdn.phototourl.com/member/2026-04-11-45ab2c01-5924-458b-9540-06ec3922e492.webp', 7, 1, '2026-03-31 17:38:18', ''),
    (10, 2, 'Kingston 16GB DDR5 4800MHz', 'RAM Kingston Fury Beast DDR5 16GB bus 4800MHz, thế hệ mới nhất, tốc độ vượt trội DDR4', 1800000.0, 20, 'https://cdn.phototourl.com/member/2026-04-11-6132eb90-14f6-404c-9ed6-e098b0d2d3bd.webp, https://cdn.phototourl.com/member/2026-04-11-9dfbcd7c-4125-4311-8507-e5b7a3c98306.webp', 9, 1, '2026-03-31 17:38:18', ''),
    (11, 3, 'Samsung SSD 500GB SATA', 'Ổ cứng SSD Samsung 870 EVO 500GB giao tiếp SATA III, tốc độ đọc 560MB/s ghi 530MB/s, bảo hành 5 năm', 1200000.0, 30, 'https://cdn.phototourl.com/member/2026-04-11-57a1db2e-9255-4597-8231-62aa9dffeb16.webp, https://cdn.phototourl.com/member/2026-04-11-157c72b2-f2ce-4aeb-a2cd-77462ba2d01b.jpg', 18, 1, '2026-03-31 17:38:18', 'SATA III, 500GB, TLC NAND'),
    (12, 3, 'Samsung SSD 1TB NVMe', 'Ổ cứng SSD Samsung 980 Pro 1TB PCIe 4.0 NVMe, tốc độ đọc 7000MB/s, phù hợp gaming và đồ họa chuyên nghiệp', 2800000.0, 18, 'https://cdn.phototourl.com/member/2026-04-11-29c5af3a-59e0-4390-a755-e6be97c79827.webp', 12, 1, '2026-03-31 17:38:18', 'PCIe 4.0 NVMe, 1TB, MLC NAND'),
    (13, 3, 'WD Blue SSD 1TB SATA', 'Ổ cứng SSD WD Blue 1TB giao tiếp SATA III, tốc độ đọc 560MB/s, độ bền cao phù hợp dùng hàng ngày', 2100000.0, 22, 'https://cdn.phototourl.com/member/2026-04-11-f126519b-e1d7-473a-9a43-2847d1104231.jpg, https://cdn.phototourl.com/member/2026-04-11-ce946e70-2cf1-4175-96d3-af2255279742.jpg', 15, 1, '2026-03-31 17:38:18', ''),
    (14, 3, 'Seagate HDD 2TB 7200RPM', 'Ổ cứng HDD Seagate Barracuda 2TB tốc độ 7200RPM, cache 256MB, phù hợp lưu trữ dữ liệu dung lượng lớn', 1450000.0, 25, 'https://cdn.phototourl.com/member/2026-04-11-26c8fffc-da65-4e3e-9220-34da6fc8f95f.png, https://cdn.phototourl.com/member/2026-04-11-1df37a42-7161-4be2-a19b-0807284b8c6a.webp', 9, 1, '2026-03-31 17:38:18', ''),
    (15, 3, 'WD Black SSD 500GB NVMe', 'Ổ cứng SSD WD Black SN770 500GB PCIe 4.0 NVMe, tốc độ đọc 5150MB/s, tối ưu cho gaming', 1600000.0, 16, 'https://cdn.phototourl.com/member/2026-04-11-03d2e8c5-54bb-4348-aeb7-0385e8e3b435.jpg, https://cdn.phototourl.com/member/2026-04-11-9420e69c-6d3f-4c34-a0ab-58c43dd84fd0.jpg', 11, 1, '2026-03-31 17:38:18', ''),
    (16, 4, 'NVIDIA RTX 3060 12GB', 'Card màn hình NVIDIA GeForce RTX 3060 12GB GDDR6, hỗ trợ Ray Tracing và DLSS, phù hợp gaming 1080p 1440p', 8900000.0, 8, 'https://cdn.phototourl.com/member/2026-04-11-ab58a678-bdd0-440b-bd8c-329f06c2a601.jpg, https://cdn.phototourl.com/member/2026-04-11-d9e4738e-b524-4f89-8029-4942f297846c.jpg', 5, 1, '2026-03-31 17:38:18', '12GB GDDR6, PCIe 4.0, 192-bit'),
    (17, 4, 'AMD RX 6600 XT 8GB', 'Card màn hình AMD Radeon RX 6600 XT 8GB GDDR6, hiệu năng gaming 1080p xuất sắc, giá thành hợp lý', 7200000.0, 6, 'https://cdn.phototourl.com/member/2026-04-11-ae2c6c59-d134-41ae-a490-2c80a94d2ce9.jpg, https://cdn.phototourl.com/member/2026-04-11-95688c21-edb3-4f79-9ece-b17aa38a12d8.jpg', 7, 1, '2026-03-31 17:38:18', ''),
    (18, 4, 'NVIDIA RTX 3070 8GB', 'Card màn hình NVIDIA GeForce RTX 3070 8GB GDDR6X, gaming 1440p và 4K mượt mà, hỗ trợ DLSS 3', 14500000.0, 5, 'https://cdn.phototourl.com/member/2026-04-11-087a055d-be72-4225-98da-9569d4d7b4ff.jpg, https://cdn.phototourl.com/member/2026-04-11-7485dea0-120b-419b-aae2-d37aeda211ca.jpg', 4, 1, '2026-03-31 17:38:18', '8GB GDDR6X, PCIe 4.0, 256-bit'),
    (19, 4, 'NVIDIA GTX 1660 Super 6GB', 'Card màn hình NVIDIA GTX 1660 Super 6GB GDDR6, gaming 1080p giá tốt, phù hợp PC tầm trung', 5800000.0, 10, 'https://cdn.phototourl.com/free/2026-04-11-bc502063-6ce1-4351-952a-fa63424170f8.webp', 13, 1, '2026-03-31 17:38:18', ''),
    (20, 5, 'ASUS B660M-K D4', 'Bo mạch chủ ASUS PRIME B660M-K D4 socket LGA1700, hỗ trợ CPU Intel thế hệ 12 13, 2 khe DDR4, Micro-ATX', 2800000.0, 12, 'https://cdn.phototourl.com/member/2026-04-11-b1fde7eb-4972-490f-aff4-cb56d1c92783.jpg, https://cdn.phototourl.com/member/2026-04-11-c53723a8-cea8-4590-b707-e25ee675c9bf.jpg', 6, 1, '2026-03-31 17:38:18', ''),
    (21, 5, 'MSI B550 Tomahawk', 'Bo mạch chủ MSI MAG B550 Tomahawk socket AM4, hỗ trợ Ryzen 3000 5000 series, PCIe 4.0, ATX', 3500000.0, 10, 'https://cdn.phototourl.com/member/2026-04-11-4d5c9e28-e80e-45ff-8343-ad044584fece.jpg, https://cdn.phototourl.com/member/2026-04-11-79d9254a-a065-43af-84cf-003fbc3f8784.jpg, https://cdn.phototourl.com/member/2026-04-11-55104643-62f2-40da-8a1e-6a7cf988cb19.jpg', 8, 1, '2026-03-31 17:38:18', ''),
    (22, 5, 'ASUS ROG Strix B550-F', 'Bo mạch chủ ASUS ROG Strix B550-F Gaming WiFi socket AM4, cao cấp, WiFi 6, 2.5G LAN, ATX', 5200000.0, 7, 'https://cdn.phototourl.com/member/2026-04-11-7d868e3e-8bcc-498c-a869-af6956d81259.jpg, https://cdn.phototourl.com/member/2026-04-11-1eb6cc96-24ed-4276-be66-71692bd4d7a6.jpg', 4, 1, '2026-03-31 17:38:18', ''),
    (23, 6, 'Corsair CV550 550W 80+ Bronze', 'Nguồn máy tính Corsair CV550 550W chuẩn 80+ Bronze, ổn định điện áp, phù hợp hệ thống tầm trung', 1250000.0, 20, 'https://cdn.phototourl.com/free/2026-04-11-d39626e1-dde1-44b8-af60-007d05ee0882.jpg, https://cdn.phototourl.com/free/2026-04-11-7c2e26ef-9845-425e-9e0d-5283dc8947ca.jpg', 10, 1, '2026-03-31 17:38:18', ''),
    (24, 6, 'Seasonic Focus GX-750 750W', 'Nguồn máy tính Seasonic Focus GX-750 750W chuẩn 80+ Gold, modular hoàn toàn, im lặng, bảo hành 10 năm', 2900000.0, 12, 'https://cdn.phototourl.com/free/2026-04-11-1fd79e31-ccad-4349-ad34-5fe51b32ed38.jpg, https://cdn.phototourl.com/free/2026-04-11-45bb9b2b-02e6-49d3-86d3-b1390f878c3f.jpg', 6, 1, '2026-03-31 17:38:18', ''),
    (25, 6, 'Corsair RM850x 850W 80+ Gold', 'Nguồn máy tính Corsair RM850x 850W chuẩn 80+ Gold, zero RPM mode, hoàn toàn modular, bảo hành 10 năm', 3800000.0, 8, 'https://cdn.phototourl.com/free/2026-04-11-ce61a0a8-b20c-4a7c-97df-fddc7c66710d.jpg, https://cdn.phototourl.com/free/2026-04-11-b4ef93b0-6e1c-4531-bfd2-5c1e3c069510.jpg', 3, 1, '2026-03-31 17:38:18', '');

-- ---- ORDERS (7 bản ghi) ----
INSERT INTO orders (id, user_id, total_price, status, order_date) VALUES
    (1, 2, 4150000.0, 'delivered', '2026-03-01 10:30:00'),
    (2, 2, 3500000.0, 'confirmed', '2026-03-10 14:20:00'),
    (3, 2, 8900000.0, 'pending', '2026-03-28 09:15:00'),
    (4, 3, 5450000.0, 'delivered', '2026-02-15 11:00:00'),
    (5, 3, 1630000.0, 'cancelled', '2026-03-05 16:45:00'),
    (6, 4, 14700000.0, 'delivered', '2026-02-20 13:30:00'),
    (7, 5, 2800000.0, 'confirmed', '2026-03-20 10:00:00');

-- ---- ORDER_ITEMS (12 bản ghi) ----
INSERT INTO order_items (id, order_id, product_id, quantity, price) VALUES
    (1, 1, 1, 1, 3500000.0),
    (2, 1, 6, 1, 650000.0),
    (3, 2, 1, 1, 3500000.0),
    (4, 3, 16, 1, 8900000.0),
    (5, 4, 7, 1, 980000.0),
    (6, 4, 11, 1, 1200000.0),
    (7, 4, 3, 1, 4200000.0),
    (8, 5, 6, 1, 650000.0),
    (9, 5, 23, 1, 1250000.0),
    (10, 6, 18, 1, 14500000.0),
    (11, 6, 10, 1, 1800000.0),
    (12, 7, 20, 1, 2800000.0);

-- ---- REVIEWS (8 bản ghi) ----
INSERT INTO reviews (id, user_id, product_id, rating, comment, created_at) VALUES
    (1, 2, 1, 5, 'CPU chạy rất mượt, giá hợp lý, giao hàng nhanh, đóng gói cẩn thận', '2026-03-31 17:38:18'),
    (2, 2, 6, 4, 'RAM ổn định, cắm vào nhận ngay không cần chỉnh XMP, hài lòng', '2026-03-31 17:38:18'),
    (3, 2, 16, 5, 'Card đẹp, chạy game 1440p siêu mượt, nhiệt độ thấp, rất đáng tiền', '2026-03-31 17:38:18'),
    (4, 3, 3, 4, 'Ryzen 5 5600X hiệu năng tốt, nhiệt độ ổn, xứng đáng với giá tiền', '2026-03-31 17:38:18'),
    (5, 3, 11, 5, 'SSD Samsung tốc độ cực nhanh, khởi động Windows chỉ 8 giây', '2026-03-31 17:38:18'),
    (6, 4, 18, 5, 'RTX 3070 chơi game 4K mượt mà, DLSS giúp tăng FPS đáng kể', '2026-03-31 17:38:18'),
    (7, 4, 10, 4, 'DDR5 tốc độ cao hơn hẳn DDR4, hệ thống responsive hơn rõ rệt', '2026-03-31 17:38:18'),
    (8, 5, 20, 4, 'Mainboard ASUS build chắc, BIOS dễ dùng, nhận RAM và CPU ngay', '2026-03-31 17:38:18');

-- ============================================================
-- THỐNG KÊ
-- ============================================================
-- SELECT COUNT(*) FROM users; -- 5 bản ghi
-- SELECT COUNT(*) FROM categories; -- 6 bản ghi
-- SELECT COUNT(*) FROM products; -- 25 bản ghi
-- SELECT COUNT(*) FROM orders; -- 7 bản ghi
-- SELECT COUNT(*) FROM order_items; -- 12 bản ghi
-- SELECT COUNT(*) FROM reviews; -- 8 bản ghi