package com.dqk.myapp.activity.admin;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dqk.myapp.R;
import com.dqk.myapp.adapter.AdminOrderAdapter;
import com.dqk.myapp.database.CategoryDAO;
import com.dqk.myapp.database.DatabaseHelper;
import com.dqk.myapp.database.OrderDAO;
import com.dqk.myapp.model.Category;
import com.dqk.myapp.model.Order;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminOrderActivity extends AppCompatActivity {

    private OrderDAO orderDAO;
    private CategoryDAO categoryDAO;
    private AdminOrderAdapter adapter;
    private List<Order> orderList;
    private List<Category> categoryList;

    private Spinner spinnerStatus, spinnerCategory;
    private String currentStatus = "all";
    private int currentCategoryId = -1; // -1 = tất cả danh mục

    private Spinner spinnerMonth;
    private int currentMonth = -1; // -1 = tất cả tháng
    private Spinner spinnerUser;
    private String currentUsername = "all"; // "all" = tất cả user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_order);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Quản lý Đơn hàng");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        orderDAO = new OrderDAO(DatabaseHelper.getInstance(this));
        categoryDAO = new CategoryDAO(DatabaseHelper.getInstance(this));
        categoryList = categoryDAO.getAll();

        loadStats();
        setupFilters();
        loadOrders();
    }

    // Hiển thị số liệu thống kê trên đầu màn hình
    private void loadStats() {
        TextView tvTotal = findViewById(R.id.tvTotalOrders);
        TextView tvRevenue = findViewById(R.id.tvTotalRevenue);
        TextView tvPending = findViewById(R.id.tvPendingOrders);

        int totalOrders = orderDAO.getAllOrders().size();
        double revenue = orderDAO.getTotalRevenue();
        int pendingOrders = orderDAO.countPendingOrders();

        tvTotal.setText(String.valueOf(totalOrders));
        tvPending.setText(String.valueOf(pendingOrders));

        NumberFormat fmt = NumberFormat.getInstance(new Locale("vi", "VN"));
        tvRevenue.setText(fmt.format(revenue) + "đ");
    }

    private void setupFilters() {
        spinnerStatus = findViewById(R.id.spinnerStatus);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerMonth = findViewById(R.id.spinnerMonth);

        //Filter theo ngày tháng
        String[] monthLabels = {"Tất cả tháng", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10", "T11", "T12"};
        ArrayAdapter<String> monthAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, monthLabels);
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMonth.setAdapter(monthAdapter);

        spinnerMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                currentMonth = (pos == 0) ? -1 : pos; // T1=1 ... T12=12
                loadOrders();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        // Filter theo trạng thái
        String[] statusLabels = {
                "Tất cả", "Chờ xác nhận", "Đã xác nhận",
                "Đã giao hàng", "Đã hủy"};
        final String[] statusValues = {
                "all", "pending", "confirmed", "delivered", "cancelled"};

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, statusLabels);
        statusAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(statusAdapter);

        spinnerStatus.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent,
                                               View view, int pos, long id) {
                        currentStatus = statusValues[pos];
                        loadOrders();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        // Filter theo danh mục
        List<String> catLabels = new ArrayList<>();
        catLabels.add("Tất cả danh mục");
        for (Category c : categoryList) catLabels.add(c.getName());

        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, catLabels);
        catAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(catAdapter);

        spinnerCategory.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent,
                                               View view, int pos, long id) {
                        // pos=0 là "Tất cả", pos>0 thì lấy category index (pos-1)
                        currentCategoryId = (pos == 0)
                                ? -1 : categoryList.get(pos - 1).getId();
                        loadOrders();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        // Filter theo user
        spinnerUser = findViewById(R.id.spinnerUser);
        List<String> userLabels = new ArrayList<>();
        userLabels.add("Tất cả user");
        userLabels.addAll(orderDAO.getAllOrderUsernames());

        ArrayAdapter<String> userAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, userLabels);
        userAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinnerUser.setAdapter(userAdapter);

        spinnerUser.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                currentUsername = (pos == 0) ? "all" : userLabels.get(pos);
                loadOrders();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadOrders() {
        int year = (currentMonth != -1)
                ? java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
                : -1;

        // Tất cả 4 filter kết hợp cùng lúc
        orderList = orderDAO.getOrdersFiltered(
                currentStatus,    // trạng thái
                currentCategoryId, // danh mục
                currentMonth,     // tháng
                year,             // năm
                currentUsername); // user

        RecyclerView rvOrders = findViewById(R.id.rvOrders);
        TextView tvEmpty      = findViewById(R.id.tvEmpty);

        if (orderList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            rvOrders.setVisibility(View.GONE);
            tvEmpty.setText("Không có đơn hàng phù hợp");
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvOrders.setVisibility(View.VISIBLE);
            if (adapter == null) {
                adapter = new AdminOrderAdapter(this, orderList, orderDAO);
                rvOrders.setLayoutManager(new LinearLayoutManager(this));
                rvOrders.setAdapter(adapter);
            } else {
                adapter.updateList(orderList);
            }
        }
    }

    // Reload stats khi quay lại màn hình
    @Override
    protected void onResume() {
        super.onResume();
        loadStats();
        loadOrders();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}