package com.dqk.myapp.activity.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dqk.myapp.R;
import com.dqk.myapp.adapter.ProductAdminAdapter;
import com.dqk.myapp.database.CategoryDAO;
import com.dqk.myapp.database.DatabaseHelper;
import com.dqk.myapp.database.ProductDAO;
import com.dqk.myapp.model.Category;
import com.dqk.myapp.model.Product;
import com.dqk.myapp.utils.FirebaseSyncManager;

import java.util.List;

public class ProductByCategoryActivity extends AppCompatActivity {

    public static final String EXTRA_CATEGORY_ID   = "category_id";
    public static final String EXTRA_CATEGORY_NAME = "category_name";

    private ProductDAO productDAO;
    private CategoryDAO categoryDAO;
    private ProductAdminAdapter adapter;
    private List<Product> productList;
    private List<Category> categoryList;
    private int categoryId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_product);

        categoryId = getIntent().getIntExtra(EXTRA_CATEGORY_ID, -1);
        String categoryName = getIntent().getStringExtra(EXTRA_CATEGORY_NAME);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(categoryName);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        productDAO   = new ProductDAO(DatabaseHelper.getInstance(this));
        categoryDAO  = new CategoryDAO(DatabaseHelper.getInstance(this));
        categoryList = categoryDAO.getAll();

        setupRecyclerView();
        setupSearch();

        Button btnAdd = findViewById(R.id.btnAddProduct);
        btnAdd.setOnClickListener(v -> showProductDialog(null));
    }

    private void setupRecyclerView() {
        // Chỉ load sản phẩm của danh mục này
        productList = (categoryId != -1)
                ? productDAO.getByCategory(categoryId)
                : productDAO.getAllProducts();

        RecyclerView rvProducts = findViewById(R.id.rvProducts);
        TextView tvEmpty        = findViewById(R.id.tvEmpty);

        if (productList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Chưa có sản phẩm nào trong danh mục này");
            rvProducts.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            rvProducts.setVisibility(View.VISIBLE);
            adapter = new ProductAdminAdapter(this, productList);
            rvProducts.setLayoutManager(new LinearLayoutManager(this));
            rvProducts.setAdapter(adapter);

            adapter.setOnActionListener(new ProductAdminAdapter.OnActionListener() {
                @Override public void onEdit(Product p)   { showProductDialog(p); }
                @Override public void onDelete(Product p) { showDeleteDialog(p);  }
            });
        }
    }

    private void setupSearch() {
        EditText etSearch = findViewById(R.id.etSearch);
        Button btnSearch  = findViewById(R.id.btnSearch);

        btnSearch.setOnClickListener(v ->
                performSearch(etSearch.getText().toString().trim()));

        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch(etSearch.getText().toString().trim());
                return true;
            }
            return false;
        });
    }

    private void performSearch(String keyword) {
        List<Product> results;
        if (keyword.isEmpty()) {
            results = (categoryId != -1)
                    ? productDAO.getByCategory(categoryId)
                    : productDAO.getAllProducts();
        } else {
            // Tìm trong danh mục hiện tại
            results = productDAO.searchProducts(keyword);
            if (categoryId != -1) {
                results.removeIf(p -> p.getCategoryId() != categoryId);
            }
        }
        if (adapter != null) adapter.updateList(results);
    }

    // Giữ nguyên showProductDialog và showDeleteDialog từ AdminProductActivity
    // (copy y hệt, chỉ đổi default categoryId khi thêm mới)
    private void showProductDialog(Product existing) {
        boolean isEdit  = (existing != null);
        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_product, null);

        EditText etName   = dialogView.findViewById(R.id.etName);
        EditText etDesc   = dialogView.findViewById(R.id.etDescription);
        EditText etPrice  = dialogView.findViewById(R.id.etPrice);
        EditText etStock  = dialogView.findViewById(R.id.etStock);
        EditText etImgUrl = dialogView.findViewById(R.id.etImageUrl);
        EditText etSpec   = dialogView.findViewById(R.id.etSpecification);
        Spinner spinner   = dialogView.findViewById(R.id.spinnerCategory);

        String[] categoryNames = new String[categoryList.size()];
        for (int i = 0; i < categoryList.size(); i++)
            categoryNames[i] = categoryList.get(i).getName();

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, categoryNames);
        spinnerAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        if (isEdit) {
            etName.setText(existing.getName());
            etDesc.setText(existing.getDescription());
            etPrice.setText(String.valueOf((int) existing.getPrice()));
            etStock.setText(String.valueOf(existing.getStock()));
            etImgUrl.setText(existing.getImageUrl());
            etSpec.setText(existing.getSpecification());
            for (int i = 0; i < categoryList.size(); i++) {
                if (categoryList.get(i).getId() == existing.getCategoryId()) {
                    spinner.setSelection(i); break;
                }
            }
        } else {
            // Mặc định chọn sẵn danh mục đang xem
            for (int i = 0; i < categoryList.size(); i++) {
                if (categoryList.get(i).getId() == categoryId) {
                    spinner.setSelection(i); break;
                }
            }
        }

        new AlertDialog.Builder(this)
                .setTitle(isEdit ? "Sửa sản phẩm" : "Thêm sản phẩm mới")
                .setView(dialogView)
                .setPositiveButton("Lưu", (dialog, which) -> {
                    String name   = etName.getText().toString().trim();
                    String desc   = etDesc.getText().toString().trim();
                    String price  = etPrice.getText().toString().trim();
                    String stock  = etStock.getText().toString().trim();
                    String imgUrl = etImgUrl.getText().toString().trim();
                    String spec   = etSpec.getText().toString().trim();

                    if (name.isEmpty() || price.isEmpty() || stock.isEmpty()) {
                        Toast.makeText(this, "Vui lòng điền tên, giá và số lượng",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int selCatId = categoryList.get(
                            spinner.getSelectedItemPosition()).getId();
                    double priceVal = Double.parseDouble(price);
                    int stockVal    = Integer.parseInt(stock);

                    if (isEdit) {
                        existing.setName(name);
                        existing.setDescription(desc);
                        existing.setPrice(priceVal);
                        existing.setStock(stockVal);
                        existing.setImageUrl(imgUrl);
                        existing.setCategoryId(selCatId);
                        existing.setSpecification(spec);
                        if (productDAO.update(existing) > 0) {
                            FirebaseSyncManager.getInstance(this).pushProductsToFirebase();
                            Toast.makeText(this, "Cập nhật thành công",
                                    Toast.LENGTH_SHORT).show();
                            refreshList();
                        }
                    } else {
                        String finalImg = imgUrl.isEmpty()
                                ? "https://cdn.phototourl.com/member/2026-04-11-ae2c6c59.jpg"
                                : imgUrl;
                        Product p = new Product(selCatId, name, desc,
                                priceVal, stockVal, finalImg);
                        p.setSpecification(spec);
                        if (productDAO.insert(p) != -1) {
                            FirebaseSyncManager.getInstance(this).pushProductsToFirebase();
                            Toast.makeText(this, "Thêm sản phẩm thành công",
                                    Toast.LENGTH_SHORT).show();
                            refreshList();
                        }
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showDeleteDialog(Product product) {
        new AlertDialog.Builder(this)
                .setTitle("Ẩn sản phẩm")
                .setMessage("Sản phẩm \"" + product.getName()
                        + "\" sẽ bị ẩn. Bạn có chắc không?")
                .setPositiveButton("Ẩn", (dialog, which) -> {
                    if (productDAO.delete(product.getId()) > 0) {
                        FirebaseSyncManager.getInstance(this).pushProductsToFirebase();
                        Toast.makeText(this, "Đã ẩn sản phẩm",
                                Toast.LENGTH_SHORT).show();
                        refreshList();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void refreshList() {
        productList = (categoryId != -1)
                ? productDAO.getByCategory(categoryId)
                : productDAO.getAllProducts();
        if (adapter != null) adapter.updateList(productList);
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
